import React from 'react'
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import IconButton from '@mui/material/IconButton';
import Stack from '@mui/material/Stack';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
export default function Userform() {
    const navigate= useNavigate();
    const [selectedUser, setSelectedUser] = useState(null);
    const [showDeleteModal, setShowDeleteModal] = useState(false);

    
    const handleEditUser = () => {
        const username = localStorage.getItem('username');
        const email = localStorage.getItem('email');
        const number = localStorage.getItem('number');
        const userDetails = { username, email, number };
        setSelectedUser(userDetails);
        navigate('/userview')
    }
    const username = localStorage.getItem('username');
        const email = localStorage.getItem('email');
        const number = localStorage.getItem('number');
        const userDetails = { username, email, number };
    const handleDeleteUser = () => {}
  return (
    <div style={{justifyContent: 'center',paddingRight: 400+'px'}}>
      <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell align="right">Email</TableCell>
            <TableCell align="right">Number</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
              <TableCell component="th" scope="row">
                {userDetails.username}
              </TableCell>
              <TableCell align="right">{userDetails.email}</TableCell>
              <TableCell align="right">{userDetails.number}</TableCell>
              <Stack direction="row" spacing={1} style={{paddingLeft: 60+'px'}} >
      <IconButton aria-label="delete">
        <DeleteIcon />
      </IconButton>
      <IconButton aria-label="edit" style={{paddingLeft: 60+'px'}} onClick={()=>handleEditUser(userDetails)}>
        <EditIcon />
      </IconButton>
      </Stack>
        </TableBody>
      </Table>
    </TableContainer>
    </div>
  )
}
