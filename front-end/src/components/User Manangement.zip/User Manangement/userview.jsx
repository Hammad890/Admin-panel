import React, { useState } from 'react'
import { Box,TextField } from '@mui/material'
import { useNavigate } from 'react-router-dom'

export default function Userview() {
    const navigate= useNavigate();
    const [userName,setUserName] =useState("");
    const [email,setEmail]= useState("");
    const [selectedUser, setSelectedUser] = useState(null);
    const [number,setNumber]= useState("");
    const handleSave=()=>{
        localStorage.setItem('username',selectedUser.userName)
        localStorage.setItem('email',selectedUser.email)
        localStorage.setItem('number',selectedUser.number)
        navigate('/userform');
    }
  return (
  <Box
      component="form"
      sx={{
        '& .MuiTextField-root': { m: 1, width: '25ch' },
      }}
      noValidate
      autoComplete="off"
    >
        <h1 style={{color:'rgb(51, 54, 238)'}}>User Details</h1>
      <div style={{display: 'flex', justifyContent:'center', flexDirection: 'column'}}>
        <TextField
          required
          id="outlined-required"
          label="User Name:"
          name='username'
          value={selectedUser? selectedUser.userName:''}
          onChange={(e)=>setSelectedUser({ ...selectedUser, userame:e.target.value})}
        />
        <TextField
          required
          id="outlined-required"
          label="Email:"
          placeholder='user2@gmail.com'
          type='email'
          name='email'
          value={selectedUser? selectedUser.email: ''}
          onChange={(e)=>setSelectedUser({ ...selectedUser, email:e.target.value})}
        />
        <TextField
          required
          id="outlined-password-input"
          label="Password"
          type="password"
          autoComplete="current-password"
          placeholder='******'
        />
        <TextField
          id="outlined-number"
          label="Number"
          type="phone number"
          defaultValue= '+92'
          name='number'
          value={selectedUser? selectedUser.number:''}
          onChange={(e)=>setSelectedUser({ ...selectedUser, number: e.target.value})}
        />
        <TextField id="outlined-search" label="Address" />
        <input type="button" onClick={handleSave}  value= 'SAVE' style={{margin:12+'px',backgroundColor:'rgb(51, 54, 238)',color:"antiquewhite",height:30+'px',width:80+'px',fontSize:18+"px"}} />
      </div>
    </Box>
  )
}
